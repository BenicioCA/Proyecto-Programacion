package proyectolospollitos;
import javax.swing.JOptionPane;
public class Rutinas {
    private Categorias[] categoria = new Categorias[2];
    
    /*CATEGORIAS*/
    
    public void registrarCategorias(){
        int x;
        for(x=0;x<categoria.length;x++){
            Categorias c= new Categorias();
            c.setNombreCat(JOptionPane.showInputDialog(null, "Ingrese el nombre de la categoria: "));
            
            categoria[x]=c;
        }
    }
    
    /*MARCAS*/
    
    private Marcas[] marca = new Marcas[2];
    
    public void registrarMarcas(){
        int x;
        for(x=0;x<marca.length;x++){
            Marcas m=new Marcas();
            m.setNombreMar(JOptionPane.showInputDialog(null, "Ingrese el nombre de marca: "));
            marca[x]=m;
        }
    }
    
    /*PRODUCTOS*/
    
    private Productos[] producto=new Productos[4];
    
   public void registrarProductos(){
        int x,y,z;
        String s = "", a ="";
        
        for(y=0;y<categoria.length;y++){
            s= s + "Categoria: " + categoria[y].getNombreCat() +"\n";
        }

        
        for(z=0;z<marca.length;z++){
            a = a + "Marcas: "+ marca[z].getNombreMar() + "\n";
        }
        
        for(x=0;x<producto.length;x++){
            Productos p=new Productos();
            p.setNombreProd(JOptionPane.showInputDialog(null, "Ingrese el nombre del producto: "));
            p.setPrecio(Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese el precio del producto: ")));
            p.setCategoria(JOptionPane.showInputDialog(null, "---CATEGORIAS---\n\n"
                                                                                                                    + s+
                                                                                                                    "\n"
                                                                                                                    +"Ingrese la categoria: "));
            
            p.setMarca(JOptionPane.showInputDialog(null, "---MARCAS---\n\n"
                                                                                                                    + a+
                                                                                                                    "\n"
                                                                                                                    +"Ingrese la marca: "));
            producto[x]=p;
        }
    }
    
    /*MERCADERIA*/
    
    public void ingresarMercaderia(){
        int x, mascantidad, cantidadactual, nuevacantidad;
        String s ="", productoBuscado = "";
        for(x=0;x<producto.length;x++){
            s = s + "Producto: " + producto[x].getNombreProd()+"\n"
                    + "   Categoria: "+producto[x].getCategoria() + "\n"
                    + "   Marca: " +producto[x].getMarca() + "\n";
            
        }
        
         JOptionPane.showMessageDialog(null, "PRODUCTOS REGISTRADOS\n\n"
                                                                                                                        + s);
         
         productoBuscado = JOptionPane.showInputDialog(null, "Ingrese el nombre del producto al que le desea añadir mercaderia: ");
         for(x=0;x<producto.length;x++){
             if(producto[x].getNombreProd().equals(productoBuscado)){
                 JOptionPane.showMessageDialog(null, "La cantidad de este producto es: "+ producto[x].getCantidad());
                 cantidadactual = producto[x].getCantidad();
                 mascantidad = Integer.parseInt(JOptionPane.showInputDialog(null, "Ingrese la cantidad que desea agregar: "));
                 nuevacantidad = cantidadactual + mascantidad;
                 producto[x].setCantidad(nuevacantidad); 
             }
         }
    }
    
    public void editarPrecio(){
         int x;
        String s ="", productoBuscado = "";
        for(x=0;x<producto.length;x++){
            s = s + "Producto: " + producto[x].getNombreProd()+"\n"
                    + "   Categoria: "+producto[x].getCategoria() + "\n"
                    + "   Marca: " +producto[x].getMarca() + "\n";
            
        }
        
         JOptionPane.showMessageDialog(null, "PRODUCTOS REGISTRADOS\n\n"
                                                                                                                        + s);
         
         productoBuscado = JOptionPane.showInputDialog(null, "Ingrese el nombre del producto al que le desea cambiar el precio: ");
        for(x=0;x<producto.length;x++){
            if(producto[x].getNombreProd().equals(productoBuscado)){
                JOptionPane.showMessageDialog(null, "El precio de este producto es: "+producto[x].getPrecio());
                producto[x].setPrecio(Float.parseFloat(JOptionPane.showInputDialog(null, "Ingrese el nuevo precio: ")));
            }
        }
    }
    
    public void verInventario(){
        int x;
        String s ="";
        for(x=0;x<producto.length;x++){
            s = s + "Producto: " + producto[x].getNombreProd()+"\n"
                    + "   Categoria: "+producto[x].getCategoria() + "\n"
                    + "   Marca: " +producto[x].getMarca() + "\n"
                    + "   Precio: " +producto[x].getPrecio() + "\n"
                    + "   Cantidad: " + producto[x].getCantidad() + "\n";
        }
        
        JOptionPane.showMessageDialog(null, "INVENTARIO\n\n"
                                                                                                                        + s);
    }
    
    public void verInventarioPormarca(){
        int x;
        String s = "", marcaBuscada;
        marcaBuscada = JOptionPane.showInputDialog(null, "Ingrese la marca que desea ver: ");
        for(x=0;x<producto.length;x++){
            if(producto[x].getMarca().equals(marcaBuscada)){
                s = s + "Producto: " + producto[x].getNombreProd()+"\n"
                    + "   Categoria: "+producto[x].getCategoria() + "\n"
                    + "   Marca: " +producto[x].getMarca() + "\n"
                    + "   Precio: " +producto[x].getPrecio() + "\n"
                    + "   Cantidad" + producto[x].getCantidad() + "\n";
                
                
            }
        }
        JOptionPane.showMessageDialog(null, "INVENTARIO\n\n"
                                                                                                                        + s);
    }
    
        public void verInventarioPorcategoria(){
        int x;
        String s = "", categoriaBuscada;
        categoriaBuscada = JOptionPane.showInputDialog(null, "Ingrese la categoria  que desea ver: ");
        for(x=0;x<producto.length;x++){
            if(producto[x].getCategoria().equals(categoriaBuscada)){
                s = s + "Producto: " + producto[x].getNombreProd()+"\n"
                    + "   Categoria: "+producto[x].getCategoria() + "\n"
                    + "   Marca: " +producto[x].getMarca() + "\n"
                    + "   Precio: " +producto[x].getPrecio() + "\n"
                    + "   Cantidad" + producto[x].getCantidad() + "\n";
                
                
            }
        }
        JOptionPane.showMessageDialog(null, "INVENTARIO\n\n"
                                                                                                                        + s);
    }
}
