package proyectolospollitos;
public class ProyectoLosPollitos {

    public static void main(String[] args) {
        Menu m=new Menu();
        m.mostrarMenu();
    }
}
