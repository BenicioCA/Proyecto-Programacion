package proyectolospollitos;

public class Categorias {
    private String nombreCat;
    
    public Categorias(){
        this.nombreCat = "";
    }

    public String getNombreCat() {
        return nombreCat;
    }

    public void setNombreCat(String nombreCat) {
        this.nombreCat = nombreCat;
    }
    
    
}
