package proyectolospollitos;

public class Productos {
    private String nombreProd;
    private float precio;
    private int cantidad;
    private String categoria;
    private String marca;
    
    public Productos(){
        this.nombreProd = "";
        this.cantidad = 0;
        this.precio = 0.00f;
        this.marca = "";
        this.categoria = "";
    }

    public String getNombreProd() {
        return nombreProd;
    }

    public void setNombreProd(String nombreProd) {
        this.nombreProd = nombreProd;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public String getCategoria() {
        return categoria;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }
    
    
}
