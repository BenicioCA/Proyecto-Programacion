package proyectolospollitos;
import javax.swing.JOptionPane;
public class Menu {
    private int opcion;
    public void mostrarMenu(){
        Rutinas r=new Rutinas();

        
       while (opcion!=9){
           opcion = Integer.parseInt(JOptionPane.showInputDialog(null,"MENU\n\n"
                    + "1- Registrar Marcas\n"
                    + "2- Registrar Categorias\n"
                    + "3- Registrar Productos\n"
                    + "4- Mercaderia\n"
                    + "5- Editar Precio\n"
                    + "6- Ver inventario completo\n"
                    + "7- Ver inventario por marca\n"
                    + "8- Ver inventario por categoria\n"
                    + "9-Salir\n"
                    + "Ingrese su opcion: "));
       
            switch(opcion){
                case 1:{
                    r.registrarMarcas();
                    break;
                }
                case 2:{
                    r.registrarCategorias();
                    break;
                }
                case 3:{
                    r.registrarProductos();
                    break;
                }
                case 4:{
                    r.ingresarMercaderia();
                    break;
                }
                case 5 :{
                    r.editarPrecio();
                    break;
                }
                case 6:{
                    r.verInventario();
                    break;
                }
                case 7:{
                    r.verInventarioPormarca();
                    break;
                }
                case 8:{
                    r.verInventarioPorcategoria();
                    break;
                }
                case 9:{
                    System.exit(0);
                    break;
                }
                default:{
                    JOptionPane.showMessageDialog(null, "Su opcion fue incorrecta");
                }
            }
       }
    }
}
