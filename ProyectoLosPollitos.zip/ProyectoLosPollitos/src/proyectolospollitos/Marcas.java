package proyectolospollitos;

public class Marcas {
    private String nombreMar;
    
    public Marcas(){
        this.nombreMar = "";
    }

    public String getNombreMar() {
        return nombreMar;
    }

    public void setNombreMar(String nombreMar) {
        this.nombreMar = nombreMar;
    }
    
    
}
